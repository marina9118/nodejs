const Sequelize = require('sequelize');
const database = "test";
const user = "root";
const password = "";
const hostname = {
    host : "localhost",
    dialect : "mysql",
    logging: false,
}

const Con = new Sequelize(database,user,password,hostname);
Con.authenticate().then(()=>{
    console.log('Connected')
}).catch((error)=>{
    console.log('Not Connected')
})

module.exports = Con;
