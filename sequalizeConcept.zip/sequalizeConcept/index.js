const express = require('express');
const app = express();
const Con = require('./Config/Database');
const Tutorial = require("./Model/Tutorial");
const web = require("./routes/web");

app.use(express.json());
app.use("/",web);
app.listen(5000);