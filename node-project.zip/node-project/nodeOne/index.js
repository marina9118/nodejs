// const app = require('./app');
// console.log(app.z());
// const colors = require('colors');
// const arr=[2,3,4,5,6,7,8,9];
// let result=arr.filter((item)=>{
//     return item===4;
// });
// console.log(result.bgBlue);
console.log("Hello");