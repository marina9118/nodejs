module.exports={
    x:10,
    y:20,
    z:function(){
        return 10;
    }
}