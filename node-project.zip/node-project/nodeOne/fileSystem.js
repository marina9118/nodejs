const fs=require("fs");
// to make file and write on it
// fs.writeFileSync("hello1.txt","Hello from me");
// to know directory name
console.log("->>",__dirname);
// to know file name
console.log("->>",__filename);