const data=[
    {name:"Marina",email:"mk@gmail.com"},
    {name:"Mishti",email:"mishti@gmail.com"},
    {name:"Mayesha",email:"mayesha@gmail.com"}
];
module.exports=data;