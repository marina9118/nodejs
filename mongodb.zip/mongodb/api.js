const express=require('express');
const dbConnect=require('./mongocon');
const app=express();

app.get('/',async (req,resp)=>{
    let db=await dbConnect();
    data=await db.find().toArray();
    resp.send(data);
})

app.listen(5000);