import React from "react";
const Footer = () =>{
    return (
        <footer>
            <p>E-Dashboard</p>
        </footer>
    );
}
export default Footer;